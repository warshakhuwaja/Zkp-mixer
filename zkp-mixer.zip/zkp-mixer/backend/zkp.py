"""
Real Schnorr Zero-Knowledge Proof of Knowledge (Fiat-Shamir, non-interactive).

This is genuine ZK crypto (not a hash-only toy): the prover proves they know
a secret exponent `x` such that `y = g^x mod p`, WITHOUT revealing `x`.

Why this is used instead of "prove knowledge of a SHA-256 preimage":
plain hash functions have no algebraic structure, so a truly
zero-knowledge, sound proof of "I know s such that H(s) = C" cannot be
built with hashing alone -- that's exactly what real zk-SNARKs are for
(they compile the hash function into an arithmetic circuit). Schnorr's
protocol is the standard, textbook way to get *real* zero-knowledge with
elementary tools, so we use it as the "secret ownership" proof, and layer
the Merkle tree + nullifier on top of it to build the Tornado-Cash-style
pool. This mirrors reality: Tornado Cash's circuit itself is basically
"prove you know a Merkle-path opening for a Pedersen/Schnorr-style
commitment," which is what we're doing here explicitly.

Protocol (Fiat-Shamir transform of Schnorr identification):
  Setup:   x  <-R- Z_q            (secret)
           y  = g^x mod p         (public commitment / "deposit key")
  Prove:   r  <-R- Z_q
           t  = g^r mod p
           c  = H(g, y, t) mod q  (challenge, derived by hashing -> non-interactive)
           s  = (r + c*x) mod q
           proof = (t, s)
  Verify:  c  = H(g, y, t) mod q
           accept iff g^s == t * y^c (mod p)
"""

import hashlib
import secrets

# A 512-bit safe prime P = 2Q + 1 (P and Q both prime), generated once and
# verified with a primality test, then hardcoded so the group is fixed and
# reproducible across server restarts. 512 bits keeps the demo fast; a real
# deployment would use a much larger, standardized group (e.g. RFC 3526).
P = 0xe9dfd509e0ebbd1d3ce780baa06ee9176aeb0a4b947b18392f5716831f6f27035c99d25ac2a63faff66946984e4e4109990cab5e5ab92987e074f63164c698d7
Q = (P - 1) // 2   # subgroup order (P is a safe prime, so Q is prime too)
G = 2              # verified below to generate the order-Q subgroup: g^Q mod P == 1

assert pow(G, Q, P) == 1, "generator does not have order Q"


def _hash_to_int(*parts: str) -> int:
    h = hashlib.sha256(("|".join(parts)).encode()).hexdigest()
    return int(h, 16) % Q


def keygen(secret_int: int):
    """Public key y = g^x mod p."""
    x = secret_int % Q
    if x == 0:
        x = 1
    y = pow(G, x, P)
    return x, y


def random_secret() -> int:
    return (secrets.randbelow(Q - 1) + 1)


def prove(x: int, y: int):
    """Produce a non-interactive Schnorr proof that we know x with y = g^x mod p."""
    r = random_secret()
    t = pow(G, r, P)
    c = _hash_to_int(str(G), str(y), str(t))
    s = (r + c * x) % Q
    return {"t": str(t), "s": str(s)}


def verify(y: int, proof: dict) -> bool:
    """Verify a Schnorr proof without ever seeing x."""
    try:
        t = int(proof["t"])
        s = int(proof["s"])
    except (KeyError, ValueError, TypeError):
        return False
    c = _hash_to_int(str(G), str(y), str(t))
    lhs = pow(G, s, P)
    rhs = (t * pow(y, c, P)) % P
    return lhs == rhs
