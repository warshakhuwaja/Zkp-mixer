"""
Privacy-preserving deposit/withdraw pool (Tornado-Cash-style), backend API.

Flow, mirroring real Tornado Cash:

  DEPOSIT
    1. Client asks the server for a fresh "note": secret x, nullifier n.
    2. Public commitment (Schnorr public key)  y  = g^x mod p
       Nullifier hash                          nh = SHA256(n)
       Merkle leaf                             leaf = SHA256(y || nh)
    3. `leaf` is inserted into the Merkle tree (the public, on-chain pool).
       The note (x, n, leafIndex) is returned to the user -- THIS is the
       only way to withdraw later, so it must be saved, exactly like a
       real Tornado Cash note.

  WITHDRAW
    1. Client presents: the note's public data (y, nullifierHash, leaf),
       a Merkle proof that `leaf` is in the tree, and a Schnorr
       zero-knowledge proof of knowledge of x (WITHOUT revealing x).
    2. Server checks:
         a) Merkle proof recomputes the current root            -> membership
         b) nullifierHash has never been seen before             -> no double-spend
         c) Schnorr proof verifies against y                     -> proves ownership
    3. If all pass, funds are released and nullifierHash is marked spent.

Privacy property: a withdrawal never reveals x (the secret) or which
*specific* deposit event funded it beyond "some leaf in the tree" -- an
observer sees a nullifier and a root, not a link back to a deposit
transaction, as long as the withdrawer doesn't reuse identifying metadata.
See README.md for the honest discussion of how this compares to real
Tornado Cash (which additionally hides the Merkle path index inside a
zk-SNARK; we keep the path visible in this simplified teaching version --
this exact limitation is discussed in README.md).
"""

from flask import Flask, jsonify, request, send_from_directory
import hashlib
import secrets
import time

from merkle import MerkleTree, verify_proof, sha256_hex
import zkp

app = Flask(__name__, static_folder="../frontend", static_url_path="")

# ---------------------------------------------------------------------------
# In-memory "blockchain" state. A real system would use a smart contract;
# this is a simulation, per the assignment.
# ---------------------------------------------------------------------------
tree = MerkleTree()
spent_nullifiers: set[str] = set()
deposit_log: list[dict] = []     # public log: {leaf, y, nullifierHash, timestamp}
withdraw_log: list[dict] = []    # public log: {nullifierHash, timestamp}
FIXED_DENOMINATION = 1.0         # like Tornado Cash, every deposit is same size


def sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
@app.route("/api/pool", methods=["GET"])
def get_pool():
    return jsonify({
        "root": tree.root(),
        "depth": tree.depth,
        "capacity": tree.capacity,
        "size": len(tree.leaves),
        "leaves": tree.leaves,
        "spentNullifiers": sorted(spent_nullifiers),
        "depositLog": deposit_log,
        "withdrawLog": withdraw_log,
        "denomination": FIXED_DENOMINATION,
    })


@app.route("/api/deposit", methods=["POST"])
def deposit():
    """
    Generates a brand new secret note, computes its public commitment, and
    inserts it into the pool. Returns the note -- the caller MUST save it,
    it is never stored server-side (exactly like a real Tornado note).
    """
    if len(tree.leaves) >= tree.capacity:
        return jsonify({"error": "Pool is full"}), 400

    x = zkp.random_secret()
    _, y = zkp.keygen(x)
    nullifier = secrets.token_hex(16)
    nullifier_hash = sha256_str(nullifier)
    leaf = sha256_hex(str(y), nullifier_hash)

    leaf_index = tree.insert(leaf)
    entry = {
        "leaf": leaf,
        "y": str(y),
        "nullifierHash": nullifier_hash,
        "leafIndex": leaf_index,
        "timestamp": time.time(),
    }
    deposit_log.append(entry)

    return jsonify({
        "note": {
            "secret": str(x),
            "nullifier": nullifier,
            "leafIndex": leaf_index,
        },
        "public": {
            "y": str(y),
            "nullifierHash": nullifier_hash,
            "leaf": leaf,
        },
        "root": tree.root(),
        "poolSize": len(tree.leaves),
    })


@app.route("/api/generate-proof", methods=["POST"])
def generate_proof():
    """
    Given a saved note (secret, nullifier, leafIndex), build everything
    needed to withdraw: the Merkle path AND a Schnorr zero-knowledge proof
    of knowledge of `secret`. The raw secret is used locally to build the
    proof but is NOT included in the returned proof object.
    """
    data = request.get_json(force=True)
    try:
        x = int(data["secret"])
        nullifier = str(data["nullifier"])
        leaf_index = int(data["leafIndex"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "Malformed note"}), 400

    if leaf_index < 0 or leaf_index >= len(tree.leaves):
        return jsonify({"error": "Unknown leaf index"}), 400

    _, y = zkp.keygen(x)
    nullifier_hash = sha256_str(nullifier)
    leaf = sha256_hex(str(y), nullifier_hash)

    if tree.leaves[leaf_index] != leaf:
        return jsonify({"error": "Note does not match the recorded deposit"}), 400

    siblings, directions = tree.proof(leaf_index)
    schnorr_proof = zkp.prove(x, y)   # x is used here, never returned

    return jsonify({
        "proof": {
            "y": str(y),
            "nullifierHash": nullifier_hash,
            "leaf": leaf,
            "merkleSiblings": siblings,
            "merkleDirections": directions,
            "schnorr": schnorr_proof,
        }
    })


@app.route("/api/withdraw", methods=["POST"])
def withdraw():
    data = request.get_json(force=True)
    proof = data.get("proof", {})

    required = ["y", "nullifierHash", "leaf", "merkleSiblings", "merkleDirections", "schnorr"]
    if not all(k in proof for k in required):
        return jsonify({"ok": False, "reason": "Malformed proof"}), 400

    # 1) Merkle membership: does this leaf really belong to the current tree?
    root = tree.root()
    if not verify_proof(proof["leaf"], proof["merkleSiblings"], proof["merkleDirections"], root):
        return jsonify({"ok": False, "reason": "Invalid Merkle membership proof"}), 400

    # 2) Double-spend protection via nullifier
    if proof["nullifierHash"] in spent_nullifiers:
        return jsonify({"ok": False, "reason": "Nullifier already spent (double-spend blocked)"}), 400

    # 3) Zero-knowledge proof of ownership -- verifies WITHOUT learning the secret
    y = int(proof["y"])
    if not zkp.verify(y, proof["schnorr"]):
        return jsonify({"ok": False, "reason": "Invalid zero-knowledge proof of ownership"}), 400

    # All checks passed: release funds, mark nullifier spent
    spent_nullifiers.add(proof["nullifierHash"])
    withdraw_log.append({
        "nullifierHash": proof["nullifierHash"],
        "timestamp": time.time(),
    })

    return jsonify({
        "ok": True,
        "message": f"Withdrawal successful: {FIXED_DENOMINATION} unit released anonymously.",
        "root": root,
    })


@app.route("/api/reset", methods=["POST"])
def reset():
    """Dev helper: wipe pool state so you can demo from scratch."""
    global tree
    tree = MerkleTree()
    spent_nullifiers.clear()
    deposit_log.clear()
    withdraw_log.clear()
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
