"""
Merkle Tree implementation for the privacy pool.

Leaves are commitment hashes (hex strings). The tree is a fixed-depth
binary tree, padded with a well-known "zero hash" for empty slots, exactly
like Tornado Cash's incremental Merkle tree (simplified: we rebuild on
every insert instead of maintaining incremental hashes, which is fine at
demo scale).
"""

import hashlib

TREE_DEPTH = 6          # supports up to 2^6 = 64 deposits
ZERO_LEAF = "0" * 64    # sentinel for an empty leaf slot


def sha256_hex(*parts: str) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(p.encode())
    return h.hexdigest()


class MerkleTree:
    def __init__(self, depth: int = TREE_DEPTH):
        self.depth = depth
        self.capacity = 2 ** depth
        self.leaves: list[str] = []
        # Precompute the hash of an "empty" subtree at every level so
        # unused branches don't need real nodes.
        self._zero_hashes = [ZERO_LEAF]
        for _ in range(depth):
            prev = self._zero_hashes[-1]
            self._zero_hashes.append(sha256_hex(prev, prev))

    def insert(self, leaf: str) -> int:
        if len(self.leaves) >= self.capacity:
            raise ValueError("Pool is full")
        self.leaves.append(leaf)
        return len(self.leaves) - 1

    def _level(self, level: int) -> list[str]:
        """Return all node hashes at `level` (0 = leaves)."""
        if level == 0:
            nodes = list(self.leaves)
            nodes += [self._zero_hashes[0]] * (self.capacity - len(nodes))
            return nodes
        below = self._level(level - 1)
        zero_below = self._zero_hashes[level - 1]
        out = []
        for i in range(0, len(below), 2):
            left, right = below[i], below[i + 1]
            out.append(sha256_hex(left, right))
        return out

    def root(self) -> str:
        if not self.leaves:
            return self._zero_hashes[self.depth]
        return self._level(self.depth)[0]

    def proof(self, index: int):
        """Return sibling hashes (bottom -> top) and left/right directions."""
        if index < 0 or index >= self.capacity:
            raise ValueError("Index out of range")
        siblings = []
        directions = []  # 'L' means sibling is on the left, 'R' means on the right
        idx = index
        for level in range(self.depth):
            nodes = self._level(level)
            is_right = idx % 2 == 1
            sibling_idx = idx - 1 if is_right else idx + 1
            sibling = nodes[sibling_idx] if sibling_idx < len(nodes) else self._zero_hashes[level]
            siblings.append(sibling)
            directions.append('L' if is_right else 'R')  # position of *sibling*
            idx //= 2
        return siblings, directions


def verify_proof(leaf: str, siblings: list[str], directions: list[str], root: str) -> bool:
    """Recompute the root from a leaf + its Merkle path and compare."""
    node = leaf
    for sib, d in zip(siblings, directions):
        if d == 'L':
            node = sha256_hex(sib, node)
        else:
            node = sha256_hex(node, sib)
    return node == root
