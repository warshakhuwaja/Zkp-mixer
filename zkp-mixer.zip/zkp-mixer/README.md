# Vault — a privacy-preserving deposit/withdraw pool (Tornado-Cash-style)

A working full-stack implementation covering both assignments: the ZKP
mini-mixer (Q1) and the PIN protocol + Merkle anonymity set (Q2).

## Running it

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000** — the Flask app serves the frontend
and the API from the same origin, so there's nothing else to configure.

Click **Deposit** to mint a note, save the note it shows you, then paste
it into the withdraw box to redeem it. The "Try double-spend" button
demonstrates the attack being blocked.

## Architecture

```
backend/
  merkle.py   – fixed-depth binary Merkle tree (SHA-256), proof gen + verify
  zkp.py      – real Schnorr non-interactive ZK proof of knowledge (Fiat-Shamir)
  app.py      – Flask API: deposit, generate-proof, withdraw, pool state
frontend/
  index.html  – single-page UI (vanilla JS, no build step)
```

### Why Schnorr instead of a hash-only "proof of preimage"

The assignment brief suggests a hash-based commit/challenge/response
scheme. It's worth being upfront about a real limitation here: **you
cannot build a sound, truly zero-knowledge proof of "I know `s` such that
`SHA256(s) = C`" using only a hash function.** Hash functions have no
algebraic structure to build a challenge-response protocol on top of —
that gap is exactly what real zk-SNARKs solve, by compiling the hash
function itself into an arithmetic circuit and proving correct evaluation
of that circuit in zero knowledge (this is what Tornado Cash's actual
Groth16 circuit does).

Rather than fake it with a hash-only protocol that either leaks the
secret or isn't actually sound, this implementation uses **Schnorr's
identification protocol**, transformed into a non-interactive proof via
Fiat-Shamir — a real, textbook zero-knowledge proof of knowledge:

- Secret: `x` (random exponent)
- Public commitment: `y = g^x mod p`
- Proof: `(t, s)` where `t = g^r mod p`, `c = H(g, y, t) mod q`, `s = r + c·x mod q`
- Verification: accept iff `g^s ≡ t · y^c (mod p)`

This is a real 512-bit safe-prime group (generated and primality-tested,
see `zkp.py`), and the same math underlies real-world systems like
Schnorr signatures (used in Bitcoin's Taproot).

## Part 1 — is this zero-knowledge? What does the verifier learn?

The Schnorr proof has the three properties that define a zero-knowledge
proof of knowledge:

- **Completeness:** if you know `x`, the equation `g^s ≡ t·y^c` always
  holds, so an honest prover always convinces the verifier.
- **Soundness:** if you don't know `x`, you'd need to answer two different
  challenges `c` with the same commitment `t` to extract `x` algebraically
  (the "special soundness" property of Sigma protocols) — you can't do
  this without knowing `x`, except by guessing correctly, which happens
  with probability `1/q` (astronomically small for a 512-bit `q`).
- **Zero-knowledge:** the verifier only ever sees `(t, s)`. Both are
  distributed independently of `x` from the verifier's point of view —
  `t` is a fresh random group element, and `s` is randomized by the fresh
  blinding factor `r`. A simulator can produce indistinguishable `(t, s)`
  pairs *without* knowing `x` at all (pick `s` at random first, then
  derive `t = g^s · y^(-c)`), which is the standard proof that the
  verifier learns nothing about `x` beyond "the prover knows it."

**Answer to "what does the verifier learn?"**: only that the prover knows
some `x` with `g^x = y` — nothing about the value of `x` itself.

### Cheating probability over repeated rounds

For a *classical* cut-and-choose ZK protocol (like the graph-based ones
covered in intro cryptography courses) with a binary challenge, a
cheating prover who doesn't know the secret succeeds in a single round
with probability `1/2`, so after `n` independent rounds:

```
P(cheat succeeds all n rounds) = (1/2)^n
n = 100  →  (1/2)^100 ≈ 7.9 × 10^-31
```

This implementation instead uses Fiat-Shamir, which achieves the same
effect in a *single* non-interactive round: the challenge space is `Z_q`
(a 512-bit range), so a cheating prover's success probability per attempt
is `1/q ≈ 2^-511` — already far smaller than repeating a 1-bit challenge
100 times. Both approaches converge to "cheating is negligible"; Fiat-Shamir
just gets there without needing repeated rounds, by making the challenge
space itself exponentially large rather than binary.

## Part 2 — Merkle tree & anonymity sets

`merkle.py` implements a standard fixed-depth (depth 6, capacity 64)
binary Merkle tree with SHA-256, `proof(index)` returning sibling hashes
bottom-to-top, and `verify_proof(leaf, siblings, directions, root)`
recomputing the root independently.

### Critical question: if an outsider sees only the root and a valid proof, can they determine which leaf was spent?

**In this simplified implementation: yes, partially** — and that's worth
being honest about rather than glossing over. The withdraw request sends
the actual `leaf` value and its sibling path, so an observer watching the
API traffic can see exactly which position in the tree is being proven.
Since `leaf = SHA256(y || nullifierHash)` is also visible in the deposit
log, an observer *can* link a specific withdrawal back to a specific
deposit event by matching leaf values.

**What genuinely stays hidden:** the secret `x` itself (via the Schnorr
ZK proof) — so even though which *slot* is being spent is visible here,
nobody can forge a withdrawal for a slot they don't control.

**How real Tornado Cash closes this gap:** production systems don't send
the leaf or the path in the clear at all. The entire Merkle-path
verification happens *inside* a zk-SNARK circuit — the circuit takes the
root and nullifier hash as the only public inputs, and the leaf, path,
and index as private inputs the circuit never reveals. The proof convinces
the verifier "some leaf in this tree opens correctly" without saying
which one. That's the actual privacy mechanism; our simplified version
demonstrates the surrounding pieces (commitment, nullifier, membership
proof, ZK ownership proof) but doesn't hide the index, since doing that
without a SNARK circuit compiler isn't achievable with elementary tools.

### Anonymity set size

The anonymity set for any single withdrawal is bounded by the number of
*unspent* deposits in the pool at the time of withdrawal (all of the same
denomination, since Tornado-style pools only mix equal amounts — mixing
different amounts would itself leak information). With `k` outstanding
deposits, a fully SNARK-hidden system gives each withdrawal a `1-in-k`
anonymity set. It grows as more people deposit and shrinks toward 1 as
the pool empties, which is why real privacy pools encourage a large,
active deposit pool and discourage withdrawing immediately after
depositing (timing correlation is a classic side-channel even when the
cryptography itself is airtight).

## Double-spend prevention

Every note contains a `nullifier`. `nullifierHash = SHA256(nullifier)` is
revealed at withdrawal time and checked against a spent-set — this is the
one piece of information that *must* leak (it's how the system prevents
reuse), but because it's independent of the deposit's public key `y`,
observing it alone doesn't reveal which deposit it came from (in a real
SNARK-based system; in this teaching version the leaf is also visible, as
discussed above).

## Attack simulation

The frontend's "Try double-spend" button reuses an already-verified proof
against `/api/withdraw` a second time; the backend rejects it because the
nullifier hash is already in the spent set. `/api/generate-proof` also
rejects any note whose recomputed leaf doesn't match what's stored in the
tree, which blocks a prover trying to claim a leaf they don't actually
control.

## Limitations (student "bonus challenge" territory)

- No real zk-SNARK — see the "critical question" discussion above for
  exactly what a SNARK would add.
- In-memory state, not a real blockchain/smart contract — restarting the
  server wipes the pool (there's a `/api/reset` endpoint for demos).
- Fixed denomination only, no relayer/gas-abstraction layer, no on-chain
  root history (only the latest root is accepted).
